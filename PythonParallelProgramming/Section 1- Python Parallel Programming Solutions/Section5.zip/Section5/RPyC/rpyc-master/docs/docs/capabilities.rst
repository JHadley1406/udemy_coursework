.. _capabilities:

Capabilities
============


Netrefs as Capabilities
-----------------------
TBD

Callbacks as Capabilities
-------------------------
TBD


