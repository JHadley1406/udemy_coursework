.. _guidelines:

Guidelines
==========

TBD:

* BgThreadedServer
* Multithreading
