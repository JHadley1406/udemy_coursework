a demonstation of events: the file monitor will send events to the client
(invoke an async callback) whenever a file is changed (as reported by os.stat)

